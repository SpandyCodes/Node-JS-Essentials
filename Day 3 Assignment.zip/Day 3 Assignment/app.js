const express = require('express');

movies = [
    {
        name:"Spider-Man: No Way Home",
        year:"2022",
        rating:"8.5",
    },
    {
        name:"She Hulk",
        year:"2022",
        rating:"8.0",
    },
    {
        name:"Dr. Strange: Multiverse of Madness",
        year:"2022",
        rating:"8.4",
    },
];

const server = express();

server.use(express.json());

server.get('/',function(req,res){
    res.json(movies);
});

server.post('/',function(req,res){
    movies.push(req.body);
    res.send('OK YOUR MOVIE HAS BEEN ADDED😊');
});

server.listen(3000,function(){
    console.log('Server is running on port 3000!😀');
});
